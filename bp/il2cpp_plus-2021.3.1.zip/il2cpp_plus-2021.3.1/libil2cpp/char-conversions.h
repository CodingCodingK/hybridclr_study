#pragma once

extern const uint8_t CategoryData_v4[71680];
extern const uint8_t NumericData[12938];
extern const double NumericDataValues[58];
extern const Il2CppChar ToLowerDataLow[9424];
extern const Il2CppChar ToLowerDataHigh[223];
extern const Il2CppChar ToUpperDataLow[9450];
extern const Il2CppChar ToUpperDataHigh[223];
