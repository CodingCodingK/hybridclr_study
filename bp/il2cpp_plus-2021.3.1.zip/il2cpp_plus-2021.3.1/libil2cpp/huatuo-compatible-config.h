#pragma once

#define HUATUO_UNITY_2021 1
#define HUATUO_UNITY_2021_OR_NEW 1

