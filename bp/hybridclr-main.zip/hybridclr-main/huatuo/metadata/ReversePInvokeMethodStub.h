#pragma oncej

#include "../CommonDef.h"

namespace huatuo
{
namespace metadata
{
	extern Il2CppMethodPointer s_ReversePInvokeMethodStub[];
}
}