#pragma once

#include "CommonDef.h"
#include "HuatuoConfig.h"

namespace huatuo
{



	class ModuleManager
	{
	public:
		static void Initialize();
	};
}