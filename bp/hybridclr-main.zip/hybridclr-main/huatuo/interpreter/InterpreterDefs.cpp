
#include "../metadata/MetadataUtil.h"

#include "MemoryUtil.h"


namespace huatuo
{
namespace interpreter
{

}
}